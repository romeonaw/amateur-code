"""
Run to start the initialization of the server
"""