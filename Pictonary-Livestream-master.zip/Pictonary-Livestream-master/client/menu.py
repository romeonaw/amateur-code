"""
To represent a specific menu, like a color palette.
"""
