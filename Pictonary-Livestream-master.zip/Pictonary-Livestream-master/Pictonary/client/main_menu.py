"""
Shows the main menu for the game, gets the user name before starting
"""


class MainMenu:
    pass